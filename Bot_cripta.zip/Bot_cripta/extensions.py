import requests
import json
from config import keys


class APIException(Exception):   # Класс для обозначения ошибок на стороне пользователя
    """Этот клас нужен для отловли ошибок, которые мог совершить пользователь при вводе сообщения боту"""
    pass


class CryptoConverter:
    """Класс предназначен для выполнения команд при этом отлавливая возможные ошибки которые может
     совершить пользователь"""

    @staticmethod
    def get_price(quote: str, base: str, amount: str) -> float:
        """Функция предназначена для выполнения команд при этом отлавливая возможные ошибки которые может
        совершить пользователь"""

        if quote == base:   # Если пользователь введёт одинаковые валюты, то вызываем ошибку
            raise APIException(f'Невозможно перевести одинаковые валюты {base}.')

        try:
            quote_ticker = keys[quote]  # Присваиваем переменной тикет валюты, которую он хочет конвертировать
        except KeyError:    # Если пользователь введёт валюту которой нет в списке валют, то вызываем ошибку
            raise APIException(f'Не удалось обработать валюту {quote}')

        try:
            base_ticker = keys[base]    # Присваиваем переменной тикет валюты, в которую будет сконвертировано
        except KeyError:    # Если пользователь введёт валюту которой нет в списке валют, то вызываем ошибку
            raise APIException(f'Не удалось обработать валюту {base}')

        try:
            amount = float(amount)  # Превращаем количество валюты, заданное пользователем в число с плавающей точкой
        except ValueError:  # Если по какой-то причине этого не удаётся сделать, то вызываем ошибку
            raise APIException(f'Не удалось обработать количество {amount}')

        if quote_ticker or base_ticker == "RUB":  # Если планируются действия с РУБЛЯМИ, то используем API из скринкаста

            # Отправляем запрос
            r = requests.get(f'https://min-api.cryptocompare.com/data/price?fsym={quote_ticker}&tsyms={base_ticker}')
            total_base = json.loads(r.content)[base_ticker]     # Получаем ответ
            return total_base   # Возвращаем результат

        else:

            # Отправляем запрос на сайт который запросил пользователь (Использую сторонний API)
            url = "https://data.fixer.io/api/latest?access_key=b1e69c757b76f88b9abece1359a27170"

            querystring = {"base": quote_ticker, "symbols": base_ticker}    # Задаём параметры для запроса
            response = requests.get(url, params=querystring)    # Отправляем запрос
            total_base = response.json()['rates'][base_ticker]      # Получаем необходимый результат

            print(response.json())    # Это нужно, чтобы просмотреть в каком виде приходят ответы с API
            print(response.json()['rates'][base_ticker])  # Убеждаемся что ответ отправляется тот который нужно
            return total_base  # Возвращаем ответ

# Данный API ОГРАНИЧИВАЕТ доступ к валюте "Рубль" поэтому использую для этой валюты API со скринкаста.
# Я не знаю с чем это связанно, но когда будете тестировать, валюту "рубль" то удалите проверку и API со скринкаста и
# оставьте сторонний API. Тогда в консоле будут приходить ответы от API и увидите ошибку, что доступ к ней ограничен.
