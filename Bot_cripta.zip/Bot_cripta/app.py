import telebot
from config import *    # Импортируем всё из библиотеки
from extensions import *     # Импортируем всё из библиотеки


bot = telebot.TeleBot(TOKEN)  # Сам бот


@bot.message_handler(commands=['start', 'help'])
def helps(message: telebot.types.Message):
    """Функция обрабатывает стартовые команды </start> и </help>
    при вводе данных команд, пользователю в ответ выводится инструкция по использованию ботом.
    Так же даёт возможность посмотреть список доступных на данный момент валют"""

    text = ('Чтобы начать работу напишите боту сообщение в следующем формате:\n<имя валюты> \
  <в какую валюту перевести>  <количество необходимой валюты>\n\nПример:\nРубль  Евро  1000\n\n\
Увидеть список доступных валют: /values')
    bot.reply_to(message, text)     # Выводим ответ на команду пользователя


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    """Функция обрабатывает команду </values>.
    При вводе команды </values> бот выводит список доступных на данный момент валют.
    Доступ к команде </values> можно получить так же через стартовые команды: </start> и </help>"""

    # Формируем текст сообщения
    text = "Доступные валюты:\n"
    for key in keys.keys():
        text = '\n'.join((text, key))
    bot.reply_to(message, text)     # Выводим ответ на команду пользователя


@bot.message_handler(content_types=['text'])
def convert(message: telebot.types.Message):
    """Функция обрабатывает текст пользователя.
    Текст должен содержать только:
    1. Имя валюты, которую пользователь хочет конвертировать;
    2. имя валюты в какую нужно перевести;
    3. Количество волюты которое ему требуется.
    Больше в сообщении пользователя ничего не должно содержаться
    И после ввода сообщения бот ему ответит"""

    try:
        # Приводим сообщение к нижнему регистру и разделяем сообщение пользователя на три части
        volume = message.text.lower().split(' ')

        if len(volume) != 3:    # Если количество элементов не равняется трём, то поднимаем ошибку
            raise APIException('Слишком много или мало параметров.')

        # quote, base, amount == валюта для конвертации, валюта в которую конвертируют, количество
        quote, base, amount = volume    # Присваиваем разделённые части переменным
        total_base = CryptoConverter.get_price(quote=quote, base=base, amount=amount)     # получаем ответ от сайта

    except APIException as e:    # если в процессе работы программы была где-то ошибка, то даём знать
        bot.reply_to(message, f'Ошибка пользователя\n{e}')  # Что ошибка вызвана пользователем

    except Exception as e:  # А эта ошибка поднимается, если в процессе работы ошибка была вызвана не пользователем
        bot.reply_to(message, f'Не удалось обработать команду\n{e}')

    else:
        # если всё прошло удачно, то пишем ответ пользователю
        text = f'Цена {amount} {quote} в {base} - {total_base * float(amount)}'
        bot.send_message(message.chat.id, text)


bot.polling()
