TOKEN = '7562914114:AAFEjr8rY28XCrCSGSNIIaEKZ_XeNiJ0qOk'  # Токен бота

keys = {                    # Словарик с валютами
    'рубль': 'RUB',
    'евро': 'EUR',
    'доллар': 'USD',
    'йена': 'JPY',
    'франк': 'CHF',
    'юань': 'CNY'
}
